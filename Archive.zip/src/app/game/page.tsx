export default function GamePage() {
    return(
        <h2 className="text-white bg-red-400">Game Page</h2>

    )
}