// app/page.tsx
"use client"

import React, { useEffect, useState } from 'react';
import { Provider, useDispatch, useSelector } from 'react-redux';
import Settings from './components/Settings/Settings';
import GameBoard from './components/GameBoard/GameBoard';
import { RootState, store } from './store';
import { setGrid, startGame } from './store/gameSlice';

const HomeComponent = () => {
    const dispatch = useDispatch();
    const { gridSize, theme, gameStarted } = useSelector((state: RootState) => state.game);
    const [countdown, setCountdown] = useState(3);

    useEffect(() => {
        const createGrid = (size: number) => {
            let values = Array(size).fill(0).map((_, i) => i % (size / 2));
            values = values.sort(() => Math.random() - 0.5);
            return values.map(value => ({ value, revealed: false, matched: false }));
        };
        dispatch(setGrid(createGrid(gridSize * gridSize)));
    }, [gridSize, theme]);

    const handleStartGame = () => {
        let timer = 3;
        const countdownInterval = setInterval(() => {
            setCountdown(timer);
            timer -= 1;
            if (timer < 0) {
                clearInterval(countdownInterval);
                dispatch(startGame());
            }
        }, 1000);
    };

    return (
        <div>
            {!gameStarted && countdown === 3 ? (
                <Settings onStartGame={handleStartGame} />
            ) : (
                <>
                    {countdown > 0 ? (
                        <div className="countdown">{countdown}</div>
                    ) : (
                        <GameBoard />
                    )}
                </>
            )}
        </div>
    );
};

const Home = () => (
    <Provider store={store}>
        <HomeComponent />
    </Provider>
);

export default Home;
