"use client"

import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { RootState } from '../../store';
import { revealTile, hideTiles, incrementScore, nextPlayer, incrementMatchedCount } from '../../store/gameSlice';
import './style.css'

const GameBoard = () => {
    const dispatch = useDispatch();
    const { grid, currentPlayer, players, matchedCount, gridSize } = useSelector((state: RootState) => state.game);
    const [selectedTiles, setSelectedTiles] = useState<number[]>([]);

    useEffect(() => {
        if (selectedTiles.length === 2) {
            const [first, second] = selectedTiles;
            if (grid[first].value === grid[second].value) {
                dispatch(incrementScore());
                dispatch(incrementMatchedCount());
            } else {
                setTimeout(() => {
                    dispatch(hideTiles());
                }, 1000);
            }
            setTimeout(() => {
                dispatch(nextPlayer());
                setSelectedTiles([]);
            }, 1000);
        }
    }, [selectedTiles]);

    const handleTileClick = (index: number) => {
        if (selectedTiles.length < 2 && !grid[index].revealed) {
            dispatch(revealTile(index));
            setSelectedTiles([...selectedTiles, index]);
        }
    };

    if (matchedCount === grid.length / 2) {
        alert(`Game Over! Player ${currentPlayer + 1} wins!`);
    }

    return (
        <div className="game_board">
            <header className='game_board_header'>
                <div className="game_board_header_left">
                    <h3>memory</h3>
                </div>
                <div className="game_board_header_right">
                    <button className="game_board_header_left_restart">Restart</button>
                    <button className="game_board_header_left_new">New Game</button>

                </div>  

            </header>
            <div className="game_board_body">
                <div className='game_board_tiles'>
                    {grid.map((tile, index) => (
                        <div key={index} className="tile" onClick={() => handleTileClick(index)}>
                            {tile.revealed ? tile.value : ''}
                        </div>
                    ))}
                </div>
            </div>
                
                <div className="scoreboard">
                    {players.map(player => (
                        <div key={player.id}>
                            <div className='scoreboard_player'>
                                Player {player.id}
                            </div>
                            <div className='scoreboard_score'>
                                {player.score}
                            </div>
                        </div>
                    ))}
                </div>
            
        </div>
    );
};

export default GameBoard;
